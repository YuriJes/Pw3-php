<?php
include("conecta.php");

$sql = "SELECT id_usuario, nm_usuario, nm_email, nm_login, nr_telefone, nm_local_foto FROM tb_usuario";
$result = $pdo->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Lista de Pilotos - Red Bull Racing</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Orbitron', sans-serif;
      background: url(pexels-jonathanborba-29327951.jpg) no-repeat center center fixed;
      background-size: cover;
      color: #eee;
    }

    .overlay {
      background: rgba(0, 0, 0, 0.85);
      min-height: 100vh;
      padding: 60px 20px;
    }

    .container-list {
      max-width: 900px;
      margin: auto;
      background: #0f111a57;
      padding: 40px 30px;
      border-radius: 16px;
    }

    .logo {
      display: flex;
      justify-content: center;
      margin-bottom: 25px;
    }

    .logo img {
      width: 180px;
      filter: drop-shadow(0 0 6px #0047bb);
    }

    h2 {
      text-align: center;
      color: #ffd700;
      margin-bottom: 25px;
      font-size: 26px;
    }

    .user-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 20px;
      padding: 20px 0;
    }

    .user-card {
      background: rgba(43, 43, 64, 0.8);
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      cursor: pointer;
      border: 1px solid #5f5757;
    }

    .user-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 5px 15px rgba(0, 71, 187, 0.5);
    }

    .user-image {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      object-fit: cover;
      margin: 0 auto 15px;
      border: 3px solid #ffd700;
    }

    .user-name {
      font-size: 18px;
      font-weight: bold;
      color: #ffd700;
      margin-bottom: 10px;
    }

    .user-detail {
      font-size: 14px;
      margin-bottom: 5px;
      color: #ccc;
    }

    .action-buttons {
      margin-top: 15px;
      display: flex;
      justify-content: center;
      gap: 10px;
    }

    .action-btn {
      padding: 8px 15px;
      border-radius: 5px;
      text-decoration: none;
      font-weight: bold;
      font-family: 'Orbitron', sans-serif;
      transition: background-color 0.3s ease, transform 0.3s ease;
      color: white;
      display: inline-flex;
      align-items: center;
      gap: 5px;
    }

    .edit-btn {
      background-color: #091396;
    }

    .edit-btn:hover {
      background-color: #0047bb;
      transform: scale(1.05);
    }

    .delete-btn {
      background-color: #dc3545;
    }

    .delete-btn:hover {
      background-color: #c82333;
      transform: scale(1.05);
    }

    .btn-back-to-form {
      display: inline-block;
      background: linear-gradient(to right, #091396, #091396);
      color: white;
      padding: 14px 25px;
      text-decoration: none;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      font-weight: bold;
      transition: all 0.3s ease;
      margin-top: 20px;
    }

    .btn-back-to-form:hover {
      background: #0047bb;
      transform: scale(1.05);
      box-shadow: 0 0 10px #091396;
    }
    
    .no-users {
      text-align: center;
      color: #ccc;
      padding: 20px;
      font-size: 16px;
    }

    /* Estilos do Modal */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.8);
    }

    .modal-content {
      background: #0f111a;
      margin: 10% auto;
      padding: 30px;
      border-radius: 16px;
      width: 80%;
      max-width: 500px;
      box-shadow: 0 0 20px rgba(0, 71, 187, 0.5);
      position: relative;
    }

    .close-modal {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }

    .close-modal:hover {
      color: #ffd700;
    }

    .modal-user-info {
      text-align: center;
    }

    .modal-user-image {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 15px;
      border: 3px solid #ffd700;
    }

    .modal-user-name {
      font-size: 24px;
      color: #ffd700;
      margin-bottom: 10px;
    }

    .modal-user-detail {
      font-size: 16px;
      margin-bottom: 8px;
      color: #ccc;
    }

  </style>
</head>
<body>
  <div class="overlay">
    <div class="container-list">
      <div class="logo">
        <img src="download.png" alt="Red Bull Racing Logo">
      </div>
      
      <h2>Pilotos Cadastrados</h2>
      
      <div class="user-grid">
        <?php
        try {
            if ($result && $result->rowCount() > 0) {
                while($row = $result->fetch(PDO::FETCH_ASSOC)) {
 
                    echo '<div class="user-card" data-id="' . $row["id_usuario"] . '" data-nome="' . htmlspecialchars($row["nm_usuario"]) . '" data-email="' . htmlspecialchars($row["nm_email"]) . '" data-login="' . htmlspecialchars($row["nm_login"]) . '" data-telefone="' . htmlspecialchars($row["nr_telefone"]) . '" data-foto="' . htmlspecialchars($row["nm_local_foto"]) . '">';

                    echo '<div class="user-name">' . htmlspecialchars($row["nm_usuario"]) . '</div>';
                    echo '<div class="user-detail"><i class="fas fa-envelope"></i> ' . htmlspecialchars($row["nm_email"]) . '</div>';
                    echo '<div class="user-detail"><i class="fas fa-user"></i> ' . htmlspecialchars($row["nm_login"]) . '</div>';
                    echo '<div class="user-detail"><i class="fas fa-phone"></i> ' . htmlspecialchars($row["nr_telefone"]) . '</div>';
  
                    echo '<div class="action-buttons">';
                    echo '<a href="" class="action-btn edit-btn"><i class="fas fa-edit"></i> Editar</a>';
                    echo '<a href="" class="action-btn delete-btn"><i class="fas fa-trash-alt"></i> Excluir</a>';
                    echo '</div>';
                    
                    echo '</div>';
                }
            } else {
                echo '<div class="no-users">Nenhum piloto encontrado</div>';
            }
        } catch (PDOException $e) {
            echo '<div class="error">Erro ao carregar dados: ' . $e->getMessage() . '</div>';
        }
        
        $pdo = null;
        ?>
      </div>
      
      <div style="text-align: center;">
        <a href="cadastro.html" class="btn-back-to-form">Voltar para Cadastro</a>
      </div>
    </div>
  </div>

  <div id="userModal" class="modal">
    <div class="modal-content">
      <span class="close-modal">&times;</span>
      <div class="modal-user-info">
     
        <h3 id="modalUserName" class="modal-user-name"></h3>
        <p id="modalUserEmail" class="modal-user-detail"></p>
        <p id="modalUserLogin" class="modal-user-detail"></p>
        <p id="modalUserPhone" class="modal-user-detail"></p>
      </div>
    </div>
  </div>

  <script>
    $(document).ready(function () {

      $('.user-card').on('click', function () {
        let card = $(this);
        let nome = card.data('nome');
        let email = card.data('email');
        let login = card.data('login');
        let telefone = card.data('telefone');
        let foto = card.data('foto');

       
        $('#modalUserImage').attr('src', foto);
        $('#modalUserName').text(nome);
        $('#modalUserEmail').html('<i class="fas fa-envelope"></i> ' + email);
        $('#modalUserLogin').html('<i class="fas fa-user"></i> ' + login);
        $('#modalUserPhone').html('<i class="fas fa-phone"></i> ' + telefone);


        $('#userModal').show();
      });

  
      $('.close-modal').on('click', function () {
        $('#userModal').hide();
      });


      $(window).on('click', function (event) {
        if (event.target.id == 'userModal') {
          $('#userModal').hide();
        }
      });
    });
  </script>
</body>
</html>