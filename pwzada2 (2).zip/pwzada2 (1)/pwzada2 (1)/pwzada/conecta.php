<?php
$host   = "localhost";
$user   = "root";
$pass   = "root"; 
$dbname = "BancodeDados";

try {

    $pdo = new PDO("mysql:host=Localhost;dbname=BancodeDados;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "";
} catch (PDOException $e) {
    die("Deu errado " . $e->getMessage());
}
?>
