<?php

include 'conecta.php'; 

$usuario = $_REQUEST["nome"];
$email   = $_REQUEST["email"];
$login   = $_REQUEST["login"];
$tele    = $_REQUEST["tele"];
$foto    = $_REQUEST["foto"]; 
$senha   = $_REQUEST["senha"];


$sql = 'INSERT INTO tb_usuario (
    nm_login, 
    nm_usuario, 
    nm_email, 
    nm_senha, 
    nr_telefone, 
    nm_local_foto
) VALUES (
    "' . $login . '", 
    "' . $usuario . '", 
    "' . $email . '", 
    "' . $senha . '", 
    "' . $tele . '", 
    "' . $foto . '"
)';

if ($pdo->exec($sql)) {
    echo 'Registro inserido com sucesso!';
} else {
    echo 'Erro ao inserir registro.';
}

?>