<?php

include 'conecta.php'; 

$login = $_POST["login"];
$senha = $_POST["senha"];

$sql = "SELECT * FROM tb_usuario WHERE nm_login = :login AND nm_senha = :senha";
$stmt = $pdo->prepare($sql);


$stmt->bindParam(':login', $login);
$stmt->bindParam(':senha', $senha); 
$stmt->execute();



if ($stmt->rowCount() > 0) {
    echo "Tudo certo";
    

    header("refresh:3;url=listar.php"); 
} else {
    echo " Login ou senha incorretos.";
}

?>